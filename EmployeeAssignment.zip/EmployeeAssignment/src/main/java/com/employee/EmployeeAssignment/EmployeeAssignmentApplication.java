package com.employee.EmployeeAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeAssignmentApplication.class, args);
	}

}
